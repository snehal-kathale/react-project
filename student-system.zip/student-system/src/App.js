// import logo from "./logo.svg";
import "./App.css";
import Api from "./component/Api";
import Dds from "./component/Dds";
// import Form from "./component/Form";

function App() {
  return (
    <div>
      {/* <Form></Form> */}
      <Api />
      {/* <Dds></Dds> */}
    </div>
  );
}

export default App;
