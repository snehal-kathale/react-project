import axios from 'axios';

class _apiService{

    getPolicies = data =>{
        return axios({
            method:'POST',
            url:'http://localhost:9090/dds-renewals/api/v1/renewals/reports',
            headers:{
                "Content-Type": "application/json",
                'Access-Control-Allow-Origin': '*'
            },
            data,
        })
    }

}

const apiService = new _apiService();

export {apiService}