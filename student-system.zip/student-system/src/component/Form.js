// import React, { useState } from "react";
// import { AllData } from "./AllData";
import Dates from "./Dates";
import Navbar from "./Navbar";
import "./style.css";
// import axios from "axios";
// import api from "./Api";

const Form = (data) => {
  //     const [resData, setResData] = useState('')

  //     const fetchData=(e)=>{
  //         // e.preventDefault();

  //         axios({
  //             'method':'POST',
  //             'url':'http://localhost:9090/dds-renewals/api/v1/renewals/reports',
  //             'headers':{
  //                 "Content-Type": "application/json",
  //                 'Access-Control-Allow-Origin': '*'
  //             },

  //             'data':{
  //                 report_type:"REN",
  //                 start_date:"11/04/2022",
  //                 end_date:"11/05/2022",
  //                 agent_code:"SO161130",
  //                 persona:"FULFI",
  //                 product_code:"",
  //                 search_criteria:{
  //                     policy_number:"P/161130/01/2020/037165",
  //                     customer_name:""
  //                 },
  //                 page_size:0,
  //                 page_number:0
  //              },
  //             withCredentials: false

  //         })

  //         // fetch('https://localhost:9090/dds-renewals/api/v1/renewals/reports')
  //         .then((res)=>{
  //             setResData(res.data)
  //             console.log(res.data)
  //         })
  //         .catch((err)=>{
  //             console.log(err)
  //         })

  //     }
  // fetchData();

  return (
    <>
      <Navbar></Navbar>
      <div className="container formsContainer pt-10 text-align: center; FormClass">
        <div className="row  ">
          <div className="">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">
                Reported Type
              </label>
              <input
                type="text"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter Reported Type"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">
                Agent Code
              </label>
              <input
                type="text"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter your agent code"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">
                Persona
              </label>
              <input
                type="text"
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter Persona"
              />
            </div>
            <Dates></Dates>
          </div>
          <button type="submit" className="btn btn-primary submitButtton">
            Submit
          </button>
        </div>
      </div>

      <data />

      <table class="table">
        <thead>
          <tr>
            <th scope="col">S No.</th>
            <th scope="col">Name</th>
            <th scope="col">Policy Number</th>
            <th scope="col">Start Date</th>
            <th scope="col">Policy Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">5</th>
            {/* <td>{data.proposer_name}</td> */}
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </>
  );
};

export default Form;
