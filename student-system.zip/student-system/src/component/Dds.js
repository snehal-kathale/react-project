import axios from "axios";
import React, { useState } from "react";

const Dds = () => {
  const [data, setData] = useState({
    report_type: "REN",
    start_date: "11/23/2022",
    end_date: "11/24/2022",
    agent_code: "SO161130",
    persona: "FULFI",
    product_code: "",
    search_criteria: {
      policy_number: "",
      customer_name: "",
    },
    page_size: 0,
    page_number: 0,
  });

  const handleChange = (e) => {
    const value = e.target.value;
    setData({
      ...data,
      [e.target.value]: value,
    });
  };

  axios
    .post({
      url: "http://localhost:9090/dds-renewals/api/v1/renewals/reports",
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      data: {
        report_type: "REN",
        start_date: "11/22/2022",
        end_date: "11/23/2022",
        agent_code: "SO161130",
        persona: "FULFI",
        product_code: "",
        search_criteria: {
          policy_number: "",
          customer_name: "",
        },
        page_size: 0,
        page_number: 0,
      },
    })
    .then((res) => {
      console.log(res);
    })
    .catch((err) => {
      console.log(err);
    });

  return <div></div>;
};

export default Dds;
