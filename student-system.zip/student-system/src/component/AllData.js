import React from "react";

export const AllData = (props) => {
  //console.log(props.response);
  console.log(JSON.stringify(props.response));
  const jsonObject = JSON.parse(JSON.stringify(props.response));
  console.log(jsonObject.results[0]);
  const dataArr = jsonObject.results[0];
  return (
    <>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">S No.</th>
            <th scope="col">Name</th>
            <th scope="col">Policy Number</th>
            <th scope="col">Start Date</th>
            <th scope="col">Policy Status</th>
            <th scope="col">Policy Status</th>
            <th scope="col">Policy Status</th>
            <th scope="col">Policy Status</th>
          </tr>
        </thead>
        <tbody>
          {dataArr.data.map((item, index) => (
            <tr>
              <th scope="row">{index + 1}</th>
              <td>{item.proposer_name}</td>
              <td>{item.previous_policy_number}</td>
              <td>{item.policy_from_date}</td>
              <td>{item.policy_status}</td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default AllData;
