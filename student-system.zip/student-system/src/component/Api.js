import React, { useEffect, useState } from "react";
import Dates from "./Dates";
import Navbar from "./Navbar";
import { apiService } from "../services/api.service";
import { AllData } from "./AllData";
import jsonData from "../renewal_response.json";

const Api = () => {
  const [allData, setAllData] = useState({
    apiResponse: "",
  });
  // const [datas, setData] = useState({
  //   report_type: "",
  //   agentCode: "",
  //   persona: "",
  //   start_date: "11/23/2022",
  //   end_date: "11/24/2022",
  // });

  // const handleData = (e) => {
  //   const value = e.target.value;
  //   setData({
  //     ...datas,
  //     [e.target.name]: value,
  //   });
  // };
  const loadData = () => {
    var data = JSON.parse(JSON.stringify(jsonData));
    setAllData({
      apiResponse: data,
    });
  };
  const fetchData = () => {
    // e.preventDefault();
    const data = {
      report_type: "REN",
      start_date: "11/23/2022",
      end_date: "11/24/2022",
      agent_code: "SO161130",
      persona: "FULFI",
      product_code: "",
      search_criteria: {
        policy_number: "",
        customer_name: "",
      },
      page_size: 0,
      page_number: 0,
    };
    console.log(data);
    //console.log(loadData);

    //   // axios({
    //   //     method:'POST',
    //   //     url:'http://localhost:9090/dds-renewals/api/v1/renewals/reports',
    //   //     headers:{
    //   //         "Content-Type": "application/json",
    //   //         'Access-Control-Allow-Origin': '*'
    //   //     },
    //   //     data:{
    //   //         report_type:"REN",
    //   //         start_date:"11/03/2022",
    //   //         end_date:"11/03/2022",
    //   //         agent_code:"SO161130",
    //   //         persona:"FULFI",
    //   //         product_code:"",
    //   //         search_criteria:{
    //   //             policy_number:"",
    //   //             customer_name:""
    //   //         },
    //   //         page_size:0,
    //   //         page_number:0
    //   //      },
    //   // })

    //   // // fetch('https://localhost:9090/dds-renewals/api/v1/renewals/reports')
    //   // .then((res)=>{
    //   //     setResData(res.data)
    //   //     console.log(res.data)
    //   // })
    //   // .catch((err)=>{
    //   //     console.log(err)
    //   // })

    // apiService.getPolicies(data).then(
    //   (res) => {
    //     const responseData = JSON.parse(JSON.stringify(res.data));
    //     console.log(responseData);
    //     setAllData({
    //       apiResponse: responseData,
    //     });
    //     //return apiResponse;
    //   },

    //   (err) => console.log(err)
    // );
  };

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   const userData = {
  //     report_type: datas.report_type,
  //     agentCode: datas.end_date,
  //     persona: datas.persona,
  //   };

  //   apiService.getPolicies(data).then(
  //     (res) => console.log(res),

  //     (err) => console.log(err)
  //   );
  // };

  return (
    <>
      <Navbar></Navbar>
      <div className="container formsContainer pt-10 text-align: center; FormClass">
        <div className="row  ">
          <div className="">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">
                Reported Type
              </label>
              <input
                type="text"
                name="report_type"
                // value={datas.report_type}
                // onChange={handleData}
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter Reported Type"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">
                Agent Code
              </label>
              <input
                type="text"
                name="agentCode"
                // value={datas.agentCode}
                // onChange={handleData}
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter your agent code"
              />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">
                Persona
              </label>
              <input
                type="text"
                name="persona"
                // value={datas.persona}
                // onChange={handleData}
                class="form-control"
                id="exampleFormControlInput1"
                placeholder="Enter Persona"
              />
            </div>
            <Dates></Dates>
          </div>
          {/* TESTING API CALL */}
          <button
            type="submit"
            className="btn btn-primary submitButtton"
            onClick={loadData}
          >
            {/* Click Me for Api call */}
            Submit
          </button>
        </div>
      </div>
      <div>
        <AllData response={allData.apiResponse} />
      </div>
      <data />
    </>
  );
};

export default Api;
