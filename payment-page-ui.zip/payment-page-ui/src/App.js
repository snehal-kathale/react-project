import React from "react";
import "./App.css";
import AppRoutes from "./components/appRoutes/AppRoutes";
import { BrowserRouter } from "react-router-dom";


function App() {
  return (
    <BrowserRouter>
      <AppRoutes></AppRoutes>
    </BrowserRouter>
  );
}

export default App;
