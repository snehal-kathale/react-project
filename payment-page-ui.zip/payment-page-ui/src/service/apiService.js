import axios from "axios";
import { paymentConfigs } from "../util/config";
import { paymentUtil } from "../util/paymentUtils";
class apiService {
  getPayment = (customer_id,headerInfo) => {
    const GET_ENDPOINT =`${paymentConfigs.BASE_URL}/paymentMethod?customer_id=${customer_id}`;
    return axios.get(GET_ENDPOINT,{headers: paymentUtil.headerUtil(headerInfo),});
  };
  createOrder = (customer_id, eapiOrder_id,headerInfo)=>{
    const GET_ENDPOINT =`${paymentConfigs.BASE_URL}/createOrder?customerId=${customer_id}&orderId=${eapiOrder_id}`;
    return axios({
      method: "POST",
      url:GET_ENDPOINT,
      headers:  paymentUtil.headerUtil(headerInfo),
    });
  }
  verifyUpi = (headerInfo,params = {}) => {
    return axios.post(`${paymentConfigs.BASE_URL}/verifyUPI`,
    params,
    {
      headers:  paymentUtil.headerFormDataUtil(headerInfo),
    });
  };

  payNow = (headerInfo, data = {}) => {
    return axios({
      method: "POST",
      url:`${paymentConfigs.BASE_URL}/paynow`,
      headers: paymentUtil.headerUtil(headerInfo),
      data,
    });
  };
}
const apiServices = new apiService();

export { apiServices };
