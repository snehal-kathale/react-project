import React from "react";

const ErrorPage = () => {
  return(
    <div>
        <p>Error occurs Redirect to Merchant page </p>
    </div>
    ) ;
};

export default ErrorPage;
