import React, { useState, useContext } from "react";
import AppContainer from "../AppContainer/AppContainer";
import { apiServices } from "../../service/apiService";
import BoxData from "../../util/BoxData";
import { ResponseData } from "../appRoutes/AppRoutes";

const Wallet = () => 
{
  var contextData = useContext(ResponseData);
  const Data = contextData.data;
  const customerId = contextData.customerId;
  const eapiOrderId =  contextData.eapiOrderId;
  const headerInfo = contextData.headerInfo;
  const preferredPayment = (Data.results[0].customer_preference[0].paymentType === "WALLET") ? Data.results[0].customer_preference[0].paymentMethod : "";
  const [value,setValue] = useState({description: "",payment_method: preferredPayment,payment_method_type: "WALLET"});
  const [quickAccess,setQuickAccess] = useState(preferredPayment);
  const [buttonDisable, setButtonDisable] = useState(!preferredPayment)
  const handleOnChange = (e) => {
    setValue({...value,...{payment_method:e.target.value}});
    setQuickAccess(e.target.value);
    setButtonDisable(false)
  };

  const onPayNowClick = async () => {
    setButtonDisable(true)
    const payload ={
      "order": {
           "orderId":eapiOrderId,
           "customerId":customerId,
          "returnUrl": process.env.REACT_APP_API_RETURN_URL
      },
      "payMethodType": value.payment_method_type,
      "payMethod": quickAccess,
      "redirectAfterPayment": true,
      "wallet": {
      }
  };

  var response = await apiServices.payNow(headerInfo, payload);
  if(response && response.data && response.data.results[0] && response.data.results[0].wallet && response.data.results[0].wallet.payment && response.data.results[0].wallet.payment.authentication && response.data.results[0].wallet.payment.authentication.url){
    const url = response.data.results[0].wallet.payment.authentication.url;
    window.open(url, "_self");
  }

  };
  return (
    <AppContainer headerText="Wallet" onPayNowClick={onPayNowClick} disabledPayNow={buttonDisable}>
      <BoxData page="Choose a wallet" handleOnChange={handleOnChange} dataDrop={Data.results[0].payment_methods[0].wallets} quickAccess={quickAccess} />
    </AppContainer>
  );
};

export default Wallet;
