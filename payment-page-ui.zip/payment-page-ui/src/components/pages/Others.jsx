import React from "react";
import AppContainer from "../AppContainer/AppContainer";

const Others = () => {
  return <AppContainer headerText="Others"></AppContainer>;
};

export default Others;
