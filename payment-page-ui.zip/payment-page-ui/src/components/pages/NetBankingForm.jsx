import React, { useState, useContext } from "react";
import AppContainer from "../AppContainer/AppContainer";
import BoxData from "../../util/BoxData";
import { apiServices } from "../../service/apiService";
import { ResponseData } from "../appRoutes/AppRoutes";


const NetBankingForm = () => {
  var contextData = useContext(ResponseData);
  const Data = contextData.data;
  const customerId = contextData.customerId;
  const eapiOrderId =  contextData.eapiOrderId;
  const headerInfo = contextData.headerInfo;
  const preferredPayment = (Data.results[0].customer_preference[0].paymentType === "NB") ? Data.results[0].customer_preference[0].paymentMethod : "";
  const [value,setValue] = useState({description: "",payment_method: "",payment_method_type: "NB"});
  const [quickAccess,setQuickAccess] = useState(preferredPayment);
  const [buttonDisable, setButtonDisable] = useState(!preferredPayment)
  const handleOnChange = (e) => {
    setValue({...value,...{payment_method:e.target.value}});
    setQuickAccess(e.target.value);
    setButtonDisable(false)
  };

  const onPayNowClick = async () => {
    setButtonDisable(true)
    const payload= {
      "order": {
          "orderId":eapiOrderId,
          "customerId":customerId,
          "returnUrl": process.env.REACT_APP_API_RETURN_URL
      },
      "payMethodType": value.payment_method_type,
      "payMethod": quickAccess,
      "redirectAfterPayment": true,
      "wallet": {
      }
  }
    var response = await apiServices.payNow(headerInfo, payload);
    if(response && response.data && response.data.results[0] && response.data.results[0].nb && response.data.results[0].nb.payment && response.data.results[0].nb.payment.authentication && response.data.results[0].nb.payment.authentication.url){
      const url = response.data.results[0].nb.payment.authentication.url;
      window.open(url, "_self");
    }
  };
  return (
    <AppContainer
      headerText="Net Banking"
      onPayNowClick={onPayNowClick}
      disabledPayNow={buttonDisable}
    >
      <BoxData page="Choose Bank"handleOnChange={handleOnChange} dataDrop={Data.results[0].payment_methods[0].netBanking} quickAccess={quickAccess} />
    </AppContainer >
  );
};

export default NetBankingForm;
