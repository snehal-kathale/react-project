import Dialog from "@mui/material/Dialog";
import Typography from "@mui/material/Typography";
import DialogContent from "@mui/material/DialogContent";
import Alert from "@mui/material/Alert";
import React, { useEffect } from "react";
import AppContainer from "../AppContainer/AppContainer";
import { useLocation } from "react-router-dom";
import { decrypt } from "../../util/AESUtils";
import { paymentUtil } from "../../util/paymentUtils";
import CountDownTimer from "../constants/CountDownTimer";
import success from "../../assets/icons/successIcon.png";
import error from "../../assets/icons/errorImg.png";
import warning from "../../assets/icons/warningIcon.png";
import { Container } from "@mui/system";

const PopUp = () => {
  const search = useLocation().search;
  const urlData = new URLSearchParams(search).get("data");
  const dataURL = decrypt(decodeURIComponent(urlData)).split("&");
  const paymentObj = paymentUtil.paymentObj(dataURL);
  const orderId = paymentObj.orderID;
  const transectionId = paymentObj.txnID;
  const url = paymentObj.url;
  const payStatus = paymentObj.status;
  const payStatusMsg = payStatus
    .split("_")
    .map((i) => i[0].toUpperCase() + i.substr(1).toLowerCase())
    .join(" ");
  const URL = `${url}?orderId=${orderId}&txnId=${transectionId}&status=${payStatus}`;

  var popStatus;
  var successMsg = ["PENDING_VBV", "CHARGED", "VBV_SUCCESSFUL"],
      errorMsg = ["AUTHENTICATION_FAILED","AUTHORIZATION_FAILED","JUSPAY_DECLINED","PENDING_VBV"];
  if (successMsg.includes(payStatus.toUpperCase())) {
    popStatus = "success";
  } else if (errorMsg.includes(payStatus.toUpperCase())) {
    popStatus = "error";
  } else {
    popStatus = "warning";
  }

  useEffect(() => {
    const timeId = setTimeout(() => {
      window.open(URL, "_self");
    }, 10000);
    return () => {
      clearTimeout(timeId);
    };
  }, []);

  return (
    <div>
      <AppContainer>
        <Container maxWidth="sm">
          <Dialog open={true}>
            <div className="AlertBox">
            <Alert
              style={{ borderRadius: "0px", height: "18%" }}
              severity={popStatus}
              variant="none"
              iconMapping={{
                success: <img src={success} className="images" alt="#" />,
                error: <img src={error} className="images" alt="#" />,
                warning: <img src={warning} className="images" alt="#" />,
              }}
            >    
            </Alert>
            </div>

            <DialogContent 
            style={{ fontSize: "0.8rem", backgroundColor: popStatus==="error"?"#d02121":popStatus==="warning"?"#df9814":"#207920"}}>
            
              <Typography style={{ fontSize: "0.8rem", borderRadius:"15px" ,backgroundColor: popStatus==="error"?"rgb(238, 210, 210)":popStatus==="warning"?"#e3c489":"rgb(200, 242, 180)" }}>
                <div className="popup_content">
                <div className="popup_padding">
                  <b>Order ID : </b> {orderId}
                </div>
                <div className="popup_padding">
                  <b>Transaction ID :</b> {transectionId}
                </div>
                <div className="popup_padding">
                  <b>Status :</b> {payStatus}
                </div>

                <p
                  style={{
                    display: "flex",
                    fontFamily: "Verdana, Geneva, Tahoma, sans-serif",
                    justifyContent: "center",
                    alignItems: "center",
                    fontWeight: "bold",
                  }}
                >
                  Payment Process {payStatusMsg}
                </p>
    
              <div className="Counter">
            
                {<CountDownTimer />}
              </div>
              <div
                style={{
                  fontFamily: "Verdana, Geneva, Tahoma, sans-serif",
                  marginLeft: "28%",
                }}
              >
                <b> Redirecting to merchant...</b>
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  rowGap: "12px",
                }}
              >
                <button
                  className="okButton"
                  onClick={() => {
                    window.open(URL, "_self");
                  }}
                >
                  OK
                </button>
              </div>
           </div>
              </Typography>
            </DialogContent>
          </Dialog>
        </Container>
      </AppContainer>
    </div>
  );
};

export default PopUp;
