import React, { useContext } from "react";
import AppContainer from "../AppContainer/AppContainer";
import { ResponseData } from "../appRoutes/AppRoutes";
import { paymentConfigs } from "../../util/config";
import { useNavigate } from "react-router-dom";

const PreferredPaymnet = () => {
  var contextData = useContext(ResponseData);
  const Data = contextData.data;
  const preferredPayment = Data.results[0].preferred_payment;
  const paymentType = {
    "CARD" : "/Credit_Debit",
    "NB" : "/net-banking",
    "WALLET" : "",
    "UPI" : ""
  }
  const navigate = useNavigate();
  return (
    <AppContainer headerText="Preferred Payment">
      <div>
        <div className="mb-3">
          <label className="form-label">Please Choose Your Bank</label>
        </div>
        <div id="group">
          <div style={{"rowGap": "20px",
          "display": "flex",
          flexDirection: "column"}}
          >
            {preferredPayment.map((items) =>{ 
              const dataValue = paymentType[items.paymentMethod];
              var preferredContend = {};
              if(items.paymentMethod === "CARD"){
                preferredContend={
                  recommend:"(Recommended)",
                  contend:"*Cards only (All Bank credit/debit cards are accepted here)"
                }
              }else if(items.paymentMethod === "NB"){
                preferredContend={
                  recommend:"(Recommended)",
                  contend:"*Preferred Net-Banking"
                }
              }
              return (
              <div>  
              <div className="radioBank">
                <input
                  className="radioButton"
                  type="radio"
                  onClick={() => {
                    navigate(dataValue);
                  }}
                  style={{ zIndex: 3 }}
                />
                <div>
                  <img style={{width:"30%"}}  src={paymentConfigs.BANK[items.paymentMethodType]} alt="#" />
                </div>
              </div>
              {/* {items.paymentMethod ==="CARD" && (<> */}
              <div style={{ color: "Red", fontSize: "1.6vw" }}>{preferredContend.recommend}</div>
            <div style={{ color: "Black", fontSize: "1vw" }}>
              {preferredContend.contend}
            </div>
            {/* </> )} */}
            </div>
            )
                })}
            
          </div>
        </div>
      </div>
    </AppContainer>
  );
};

export default PreferredPaymnet;
