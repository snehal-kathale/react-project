import React, { useState, useContext } from "react";
import AppContainer from "../AppContainer/AppContainer";
import { apiServices } from "../../service/apiService";
import "bootstrap/dist/css/bootstrap.min.css";
import BoxData from "../../util/BoxData";
import FormData from 'form-data';
import { ResponseData } from "../appRoutes/AppRoutes";

const reqBody = {
  order: {
    amount: 100,
    customerId: "8408099842",
    customerPhone: "8408099842",
    customerEmail: "test42@gmail.com",
    currency: "INR",
    returnUrl:
    process.env.REACT_APP_API_RETURN_URL,
  },
  payMethodType: "UPI",
  payMethod: "UPI",
  redirectAfterPayment: true,

  upi: {
    upiVpa: "9999999999@upi",

    txnType: "UPI_COLLECT",
  },
};

const UpiForm = () => {
  var contextData = useContext(ResponseData);
  const headerInfo = contextData.headerInfo;
  const [disabledPayNow, setDisabledPayNow] = useState(false);
  const [validUPI, SetValidUPI]=useState(false)
  const [disabledVerify, setDisabledVerify] = useState(false);
  const [vpa, setVpa] = useState();
  const [msg, setMsg] = useState(false);

  const handleOnChange = (event) => {
    if(/^[\w.-]+@[\w.-]+$/.test(event.target.value)){
    setMsg(false);
    setDisabledVerify(true)
    }
    else{
    setMsg(true);
    }

    setVpa(event.target.value);
  };
  const handleOnClick = () => {
    const formData = new FormData();
    formData.append('vpa', vpa);
    const param = formData;
    apiServices.verifyUpi(headerInfo,param).then(
      (response) => {
        const res = JSON.parse(JSON.stringify(response.data));
        if (res.results[0].status === "VALID") {
          setDisabledPayNow(true);
        } else{
        SetValidUPI(true)
        setDisabledPayNow(false);
        }
      },
      (err) => {
        console.log("err", err);
      }
    );
  };

  const handleOnPayNow = () => {
    apiServices.payNow(reqBody).then(
      (res) => {
        const response = JSON.parse(JSON.stringify(res.data));
        const url = response.results[0].upi.payment.authentication.url;
        window.open(url, "_self");
      },

      (err) => console.log(err)
    );
  };

  return (
    <AppContainer
      headerIcon=""
      headerText="UPI"
      onPayNowClick={handleOnPayNow}
      disabledPayNow={!disabledPayNow}
    >
      <BoxData page="UPI" handleOnChange ={handleOnChange} onVerifyClick={handleOnClick} validErrMsg={msg} disabledVerify={!disabledVerify} validUPI={validUPI}/>
    </AppContainer>
  );
};

export default UpiForm;
