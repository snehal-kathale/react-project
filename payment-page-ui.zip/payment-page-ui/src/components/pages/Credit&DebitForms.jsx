import AppContainer from "../AppContainer/AppContainer";
import { useEffect, useState, useContext } from "react";
import { apiServices } from "../../service/apiService";
import { ResponseData } from "../appRoutes/AppRoutes";
const CreditDebitForms=()=>{
    const [url, setUrl] = useState("");
    var contextData = useContext(ResponseData);
    const customerId = contextData.customerId;
    const eapiOrderId =  contextData.eapiOrderId;
    const headerInfo = contextData.headerInfo;

    useEffect( ()=>{
     apiServices.createOrder(customerId,eapiOrderId,headerInfo).then((response)=>{
        if(response && response.data && response.data.results[0] && response.data.results[0].iframeLink){
            setUrl(response.data.results[0].iframeLink+"?payment_options=card&mobile=true")
        }
    })
    },[])
    return (
        <AppContainer
        headerText="CARD DETAILS"
        className="card"
        >
            <iframe src={url} width={"100%"} height={"100%"} /> 
        </AppContainer>
    );
};

export default CreditDebitForms;