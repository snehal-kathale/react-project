import {useEffect, createContext, useState,} from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { apiServices } from "../../service/apiService";
import NetBankingForm from "../pages/NetBankingForm";
import UpiForm from "../pages/UpiForm";
import Wallet from "../pages/Wallet";
import PreferredPaymnet from "../pages/PreferredPaymnet";
import CreditDebitForms from "../pages/Credit&DebitForms";
import Others from "../pages/Others";
import PopUp from "../pages/PopUp";
import { paymentUtil } from "../../util/paymentUtils";
import { decrypt } from "../../util/AESUtils";
import ErrorPage from "../pages/ErrorPage";
export const ResponseData = createContext(null);
export const ThemeSet = createContext(null);


const themeCollection = {
  "Blue":["#040748", "#efefef", "Blue"],
  "Green":["#103006", "#d1efce", "Green"],
  "Violet":["#3b035c", "#f9e2fb", "Violet"]
}; 
const AppRoutes = () => 
{
  const [theme,setTheme] = useState({
    theme:["#040748", "#efefef", "Blue"],
    onThemeChange:  (e)=>{
      var val = Object.keys(themeCollection).filter((items)=>{
        return e === items
      });
      setTheme({...theme,...{theme:themeCollection[val]}});
    }
    });
  var [data,setData]=useState();
  const search = useLocation().search;
  var [paymentObj,setPaymentObj]=useState();
  var flag = false;
  useEffect(()=>{
    const urlData = new URLSearchParams(search).get("data");
    const dataURL = decrypt(decodeURIComponent(urlData)).split("&");
    setPaymentObj(paymentUtil.paymentObj(dataURL));
    if((window.location.href).includes("payments")){
      paymentObj = paymentUtil.paymentObj(dataURL);
      sessionStorage.setItem("eapiOrderID", "Active");
      const headerInfo = {
        auth: paymentObj.auth,
        channelID:  paymentObj.channelID,
        requestUID: paymentObj.requestUID
      }
      if(!paymentObj.orderID) 
        apiServices.getPayment(paymentObj.customerID,headerInfo).then(
          (res) => {
            if(res && res.data && res.data)
              setData({data:res.data,
                customerId:paymentObj.customerID,
                eapiOrderId:paymentObj.eapiOrderID,
                headerInfo:headerInfo,
              });
          },
          (err) => console.log(err)
        );
    }else if((window.location.href).includes("results") && sessionStorage.eapiOrderID === "Active"){
      flag=true
      sessionStorage.clear();
    }
  },[])
  useEffect(()=>{
    setTimeout(() => {
      window.history.forward()
    }, 0)
  })
 useEffect(()=>{
  window.addEventListener("beforeunload",(e)=>{
    e.preventDefault();
  })
 })

  return ( 
   
    <ThemeSet.Provider value = {theme}>
    <ResponseData.Provider value={data}>
        {(data || (paymentObj && paymentObj.orderID)) 
         &&
        <Routes>
          <Route exact path="/payments" element={ 
        <PreferredPaymnet />}></Route>
          <Route exact path="/Credit_Debit" element={<CreditDebitForms />} />
          <Route exact  path="/net-banking" element={<NetBankingForm />} ></Route>
          <Route exact path="/wallet" element={<Wallet />} />
          <Route exact path="/upi" element={<UpiForm />} />
          <Route exact path="/others" element={<Others />} />
          <Route exact path="/results" element={flag?<PopUp />:<ErrorPage />}></Route>
        </Routes>
        }
    </ResponseData.Provider>
    </ThemeSet.Provider>
    
  );
};

export default AppRoutes;
