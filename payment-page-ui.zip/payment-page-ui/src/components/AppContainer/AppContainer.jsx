import { useContext } from "react";
import styled from "styled-components";
import Header from "../constants/Header";
import Navigation from "../constants/Navigation";
import PageWatermark from "../constants/PageWatermark";
import { ThemeSet } from "../appRoutes/AppRoutes";
import Footer from "../constants/Footer";

const AppWrapper = styled.div`
 
  .card-wrapper {
    position: relative;
    height: 80vh;
    margin: 2% 20% 0 20%;
    border: 1px solid rgb(237 230 230);
    border-radius: 9px;
    box-shadow: rgb(50 50 93 / 25%) 0px 13px 27px -5px,
      rgb(0 0 0 / 30%) 0px 8px 16px -8px;
  }

  .body-wrapper {
    display: grid;
    grid-template-columns: 30% auto;
    height: 80vh;
  }

  .page-wrapper {
    height: 67%;
    margin: 32px;
    border: 1px solid rgb(193 187 187);
    font-size: 1vw;
    font-weight: 500;
    color: rgb(159 150 150);
    padding: 5% 15% 1% 12%;
    border-radius: 7px;
  }
  
  .page-header {
    color: #040748;
    font-size: 1.3vw;
    font-weight: 700;
    padding: 2% 3% 2% 3%;
    border-bottom: 1px solid rgb(193 187 187);
  }
  .content {
    position: relative;
    background:  ${props => props.theme[1]};
  }
  .page-footer {
    position: absolute;
    bottom: 0px;
    padding: 2% 5% 2% 2%;
    display: grid;
    width: 100%;
    grid-template-columns: 1fr max-content;
    border-top: 1px solid rgb(193 187 187);
  }
  .pay-button{
    background-color:${props => props.theme[0]};
  color: white;
  font-size: 1vw;
  padding: 5px 20px;
    border: 0px solid ;
  border-radius: 7px;
  box-shadow: 0 8px 18px 0 rgba(0,0,0,0.4), 0 6px 20px 0 rgba(0,0,0,0.4);
  }
  .press-effect:active {
    box-shadow: 0px 4px 8px #333;
    -webkit-transform: scale(0.98);
    transform: scale(0.98);
  }
  .ver-button {
    box-shadow: 0 8px 18px 0 rgba(0,0,0,0.4), 0 6px 20px 0 rgba(0,0,0,0.4);
    padding: 2%;
    margin-left: 3%;
    border-radius: 4px;
    width: 30%;
    background-color: ${props => props.theme[0]};
    color: white;
    border: 0px solid;
    font-size: 1vw;
  }
`;

const AppContainer = (props) => {
  const {
    children,
    headerText,
    onPayNowClick,
    disabledPayNow,
    preferredPaymentOption,
    className = "",
  } = props;
  const themeData = useContext(ThemeSet);
  return (
    <AppWrapper theme={themeData.theme}>
      <div className="header-wrapper">
        <Header themeValue={themeData.theme[2]} onThemeChange={themeData.onThemeChange}/>
      </div>
      <div className="card-wrapper">
        <div className="body-wrapper">
          <Navigation  theme={themeData.theme[0]}/>
          <div className="content">
            <div className="page-header">{headerText}</div>
            <div className={"page-wrapper" + " " + className}>
              {children} {preferredPaymentOption}
            </div>
            <div className="page-footer">
              <div />
              {headerText !== "Preferred Payment" &&
                headerText !== "CARD DETAILS" && (
                  <button
                    className="pay-button press-effect"
                    disabled={disabledPayNow}
                    onClick={onPayNowClick}
                  >
                    Pay Now
                  </button>
                )}
            </div>
          </div>
         
        </div>
        <PageWatermark/>
      </div>
        <Footer/>
    </AppWrapper>

  );
};

export default AppContainer;
