import React from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
import preferredIcon from "../../assets/icons/PREF.png";
import cardIcon from "../../assets/icons/CARD.png";
import walletIcon from "../../assets/icons/WALLET.png";
import upiIcon from "../../assets/icons/UPI.png";
import netBankIcon from "../../assets/icons/BANK.png";
import otherIcon from "../../assets/icons/Others.png";

const Wrapper = styled.div`
  background: ${props=> props.theme};
  padding: 6%;
  display: flex;
  flex-direction: column;
  row-gap: 2%;
  border-radius: 10px 0px 0px 10px;
`;

const StyledLink = styled(Link)`
  display: inline-block;
  text-decoration: none;
  color: white;
  padding: 5%;
  font-size: 1.2vw;
`;

const sidebarNavItems = [
  {
    display: "Preferred Payment",
    icon: <img src={preferredIcon} className="icon" alt="#" />,
    to: "/payments",
    section: "",
  },
  {
    display: "Credit & Debit Cards",
    icon: <img src={cardIcon} className="icon" alt="#" />,
    to: "/Credit_Debit",
    section: "",
  },
  {
    display: "Wallets",
    icon: <img src={walletIcon} className="icon" alt="#" />,
    to: "/wallet",
    section: "",
  },
  {
    display: "Net Banking",
    icon: <img src={netBankIcon} className="icon" alt="#" />,
    to: "/net-banking",
    section: "",
  },
  {
    display: "UPI Payments",
    icon: <img src={upiIcon} className="icon" alt="#" />,
    to: "/upi",
    section: "",
  },
  {
    display: "Others",
    icon: <img src={otherIcon} className="icon" alt="#" />,
    to: "/others",
    section: "",
  },
];

const Navigation = ({theme}) => (
  <Wrapper theme={theme}>
    {sidebarNavItems.map((items, key) => (
      <div className="navSideBarDiv" key={key} style={{ zIndex: 3 }}>
        {items.icon}
        <StyledLink to={items.to}>{items.display}</StyledLink>
      </div>
    ))}
  </Wrapper>
);
export default Navigation;
