import React from "react";
import styled from "styled-components";
import Logo from "../../assets/images/starLogo.png";
import Tooltip from '@mui/material/Tooltip';

const Wrapper = styled.div`
  padding: 1%;
  display: grid;
  grid-template-columns: 100px 1fr;
  grid-gap: 80%;
  align-items: center;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  .logo-wrapper {
    margin-left:13%
    max-width: 145px;
    max-height: 55px;
  }

  .text-wrapper {
    font-weight: 750;
    color:#111672
  }
  .${props => props.theme}{
    border: 6px solid white;
  }
  .theme-Container{
    display : flex;
    column-gap : 7%;
    
  }
`;

const Header = ({themeValue, onThemeChange}) => {
  const styles={
    fontSize:"1vw",
    fontWeight:"800",
  }
  return (
    <Wrapper theme={themeValue?themeValue:"Blue"}>
      <img src={Logo} alt="Logo" className="logo-wrapper" />
      <div className="theme-Container">
      <Tooltip title="Blue">
        <div className="dot Blue" onClick={()=>{onThemeChange("Blue")}} style={{backgroundColor: "rgb(205 203 231)"}} name="Blue">
          <p color="#040748" style={styles}>B</p>
        </div>
        </Tooltip>
        <Tooltip title="Green"> 
        <div className="dot Green"   onClick={()=>{
          onThemeChange("Green")
        }} style={{backgroundColor: "#d1efce"}} name="Green">
          <p color="#103006" style={styles}>G</p>
        </div>
        </Tooltip> 
        <Tooltip title="Violet">
        <div className="dot Violet"  onClick={()=>{
          onThemeChange("Violet")
        }}  style={{backgroundColor: "#f9e2fb"}} name="Violet">
          <p color="#3b035c" style={styles}>V</p>
        </div>
        </Tooltip>
      </div>
    </Wrapper>
  );
};

export default Header;
