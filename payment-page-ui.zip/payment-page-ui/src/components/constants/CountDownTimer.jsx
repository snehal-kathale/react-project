import React from "react";
import { CountdownCircleTimer } from "react-countdown-circle-timer";

const CountDownTimer = () => {
  return (
    <div style={{ width: "80px", height: "80px" }}>
      <CountdownCircleTimer
        isPlaying
        duration={10}
        colors={["#004777", "#F7B801", "#A30000", "#A30000"]}
        colorsTime={[10, 6, 3, 0]}
        size="80"
        strokeWidth="4"
        strokeLinecap="round"
      >
        {({ remainingTime }) => (
          <div style={{ fontSize: "22px", textAlign: "center" }}>
            {remainingTime}
          </div>
        )}
      </CountdownCircleTimer>
    </div>
  );
};
export default CountDownTimer;
