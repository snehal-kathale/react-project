import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
  .page-header {
    background:white;
    position: absolute;
    padding-top: 16px;
    padding-right: 520px;
    padding-left: 32px;
    padding-bottom: 16px;
    border-bottom: 1px black;
    font-weight: 400;
    color: #040748;
    font-size: 18px;
    top: 132px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
   
    
`;

const PageHeader = (props) => {
  return (
    <Wrapper>
      <div className="page-header"></div>
    </Wrapper>
  );
};

export default PageHeader;
