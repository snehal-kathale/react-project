import { fontSize, textAlign } from '@mui/system'
import React from 'react'
import styled from 'styled-components'

const Box = styled.div`
  top:100%;
  padding: 25px 15px;
  position: absolute;
  background:#040748 ;
  left:0;
  width: 100%;
  margin-top: 1rem;
  margin-bottom:0px;

  @media (max-width: 1000px) {
    padding: 35px 25px;
   
  }

  .Container{
    display: flex;
    text-align: center;
    flex-direction: column;
    justify-content: center;
    max-width: 1000px;
    margin: 0 auto;
    color:white;
    margin-bottom: auto;
    font-size: 13px;
    font-family: Arial, Helvetica, sans-serif;
   
  }
  .footer-link{
   
    font-size: 16px;
    text-decoration: none;
    text-align: center;
    font-family: Arial, Helvetica, sans-serif;
    color:white;
  
  }
  .text{
    text-align: center;
    font-family: Arial, Helvetica, sans-serif;
    color:white;
  }
 
`

const Footer=() =>{

  return (
    <Box>
        <h1 style={{color:"white", textAlign:"center", fontWeight:"bold",
    fontSize:"16px"}}>
About StarHealth
        </h1>
    <div className="Container">
        <p> Star Health and Allied Insurance Co Ltd is an Indian multinational health insurance company
                        headquartered in Tamil Nadu, Chennai.
                        The company provides services in health, personal accident and overseas travel insurance,
                        directly as well as through various channels like agents, brokers and online.</p>            
        <div className="footer-link" >
            © 2023 Copyright:
            <a className="text" href="https://www.starhealth.in/">Star Heatlth</a>
        </div>
    </div>
        </Box>
  )
}

export default Footer