import React from "react";
import WatermarkLogo from "../../assets/images/Watermark.png";

const PageWatermark = () => {
  return (
   
    <div 
      style={{
        pointerEvents:"none",
        opacity: 0.17,
        position: "absolute",
        backgroundImage: `url(${WatermarkLogo})`,
        backgroundSize: "contain",
        backgroundRepeat: "no-repeat",
        rotate: "340deg",
        top: "80px",
        left:"30px",
        width: "90%",
        height: "400px",
        // height:"80vh",
      }}
    />
  
  );
};

export default PageWatermark;

