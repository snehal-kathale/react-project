import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
  .page-footer {
    //margin-top: 300px;
    //padding-top: 500px;
    // // padding-right: 519px;
    // padding-left: 400px;
    // padding-bottom: 28px;
    // border-bottom: 1px black;
    // font-weight: 400;
    //color: #040748;
    // font-size: 18px;
    position: fixed;
  }
  .btnpaynow {
    background-color: #040748;
    color: white;
    padding: 16px 32px;
    // // display: flex;
    // // justify-content: center;
    // // position: relative;
    // top: 400px;
    // left: 540px;
    cursor: pointer;
  }
  .btnreset {
    background-color: #040748;
    color: white;
    padding: 16px 32px;
    // display: flex;
    // justify-content: center;
    // position: relative;
    // top: 341px;
    // left: 430px;
    cursor: pointer;
  }
`;

const PageFooter = () => {
  return (
    <Wrapper>
      <div className="page-footer">
        <button className="btnpaynow">Paynow</button>
        <button className="btnreset">reset</button>
      </div>
    </Wrapper>
  );
};

export default PageFooter;
