// import { createClient } from 'redis';
// const client = createClient({
//     password: '<password>',
//     socket: {
//         host: 'https://shaic-entpayments-test-dev-ent-payments-svc.apps.shaioc-np.70sr.p1.openshiftapps.com',
//         port: 6379
//     }
// });

const redis = require('redis')

const Client= redis.createClient({
                password: process.env.REDIS_PASSWORD,
                host: process.env.REDIS_HOST_URL,
                port: 6379
  
})

Client.on('connect',()=>{
    console.log("client connected to redis...")
})

Client.on('ready',()=>{
    console.log("client connected to redis and ready to use...")
})

Client.on('error', (err)=>{
    console.log(err.message)
})

Client.on('end',()=>{
    console.log("client disconnected from redis ...")
})

process.on('SIGINT',()=>{
    Client.quit()
})

module.export = Client