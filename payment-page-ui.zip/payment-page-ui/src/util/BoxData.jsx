import React from "react";
import { Box } from "@mui/system";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import axis from "../assets/icons/axisIcon.png";
import iob from "../assets/icons/iobIcon.png";
import sbi from "../assets/icons/sbiIcon.png";
import union from "../assets/icons/unionIcon.png";
const BoxData = ({
  page,
  handleOnChange,
  dataDrop,
  quickAccess,
  onVerifyClick,
  validErrMsg,
  disabledVerify,
  validUPI,
}) => {
  var dropDownData;
  var quickData = {};
  const images = [axis, iob, sbi, union];
  if (page === "UPI") {
  } else {
    dropDownData = dataDrop.map((items, key) => {
      if (quickAccess && items.payment_method === quickAccess) {
        quickData = { ...items, ...{ icon: images[key] } };
      }
      return { ...items, ...{ icon: images[key] } };
    });
  }
  return (
    <div className="Wrapper">
      <Box
        sx={{
          "& .MuiTextField-root": { m: 1, width: "20vw" },
        }}
      >
        <div>
          <label>Quick Access :</label>
          <div>
            {quickAccess ? (
              <TextField
                size="small"
                InputProps={{
                  startAdornment: (
                    <>
                      <ListItemIcon>
                        <img src={quickData.icon} alt="#" style={{width:"1vw"}}/>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <span
                          style={{
                            color: "rgba(0, 0, 0, 0.87)",
                            fontSize: "1.2vw",
                          }}
                        >
                          {quickData.description}
                        </span>
                      </ListItemIcon>
                    </>
                  ),
                }}
              ></TextField>
            ) : (
              <div style={{ padding: "4%" }}></div>
            )}
          </div>
        </div>
      </Box>

      {page === "UPI" ? (
        <Box
          sx={{
            "& .MuiTextField-root": { m: 1, width: "20vw" },
          }}
        >
          <label>Virtual Payment Address:</label>
          <div>
            <TextField
              size="small"
              placeholder="Enter Your VPA"
              onChange={handleOnChange}
            ></TextField>
          </div>
          {validErrMsg && (
            <div style={{ color: "red" }}>Please Enter the Correct VPA</div>
          )}
          <div className="verify">
            <button
              className="ver-button press-effect"
              onClick={onVerifyClick}
              disabled={disabledVerify}
              style={{ zIndex: 3 }}
            >
              Verify
            </button>
            {validUPI && (
              <label className="lab Inv">VPA Verification Failed</label>
            )}
          </div>
        </Box>
      ) : (
        <Box
          sx={{
            "& .MuiTextField-root": { m: 1, width: "20vw" },
          }}
        >
          <div>
            <label>Other Option:</label>
            <div>
              <TextField
                size="small"
                select
                label="Select One"
                onChange={handleOnChange}
              >
                {dropDownData.map((item, key) => (
                  <MenuItem key={key} value={item.payment_method}>
                    <ListItemIcon>
                      <img src={item.icon} alt="#" style={{width:"1vw"}}/>
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      <span
                        style={{
                          color: "rgba(0, 0, 0, 0.87)",
                          fontSize: "1.2vw",
                        }}
                      >
                        {item.description}
                      </span>
                    </ListItemIcon>
                  </MenuItem>
                ))}
              </TextField>
            </div>
          </div>
        </Box>
      )}
    </div>
  );
};

export default BoxData;
