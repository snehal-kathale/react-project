import { paymentConfigs } from "./config";
export const paymentUtil={
    headerUtil:(params)=>{
        return {
            "sh-client-context":paymentConfigs.contextConfig(params),
            requestUID: params.requestUID,
            Authorization:params.auth,
          }
    },
    headerFormDataUtil:(params)=>{
        return {
            "sh-client-context":
            paymentConfigs.contextConfig(params),
            requestUID: params.requestUID,
            "content-type": "multipart/form-data",
            Authorization:
            params.auth,
          }
    },
    paymentObj:(params)=>{
        const obj = {}
        params.map((item)=>{
            var valIndex = item.indexOf("=");
            obj[item.substring(0,valIndex)]=item.substring(valIndex+1);
        });
        return obj
    }
}