import CryptoJS from 'crypto-js';
import axis from "../assets/icons/axisIcon.png";
import iob from "../assets/icons/iobIcon.png";
import sbi from "../assets/icons/SBIPF.png";
import union from "../assets/icons/unionIcon.png";
import HDFCIcon from "../assets/icons/HDFC1.png";
import KOTAKIcon from "../assets/icons/KOTAK.png";

export const paymentConfigs={
    BANK:{
        "SBI":sbi,
        "HDFC":HDFCIcon,
        "IOB":iob,
        "UNION":union,
        "AXIS":axis,
        "KOTAK":KOTAKIcon,
    },
    BASE_URL : process.env.REACT_APP_API_ENDPOINT,
    ENCRYPTER:window.atob(process.env.REACT_APP_ENCRYPTER),
    ENCRYPTER_IV:window.atob(process.env.REACT_APP_ENCRYPTER_IV),
    contextConfig:(params)=>{
        var contextObj = {
            "requestUID":params.requestUID,
            "country":"IN",
            "channelID":params.channelID,
            "accessid":"'juspayordstatuv1",
            "clientIp":"10.2.3.10",
            "lang":"EN",
            "srcSystemName":"Portal",
            "srcClientId":"WEB",
            "rumEvents":"rumEventStrings"
            }
        var sh_context_Data = CryptoJS.enc.Utf8.parse(JSON.stringify(contextObj));
        return CryptoJS.enc.Base64.stringify(sh_context_Data)
    }

};