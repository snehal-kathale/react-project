import CryptoJS from "crypto-js";
import {paymentConfigs} from "../util/config";
export const decrypt = (params)=>{
    var decrypted = CryptoJS.AES.decrypt({
    ciphertext: CryptoJS.enc.Base64.parse(params) //decode
  },CryptoJS.enc.Hex.parse(paymentConfigs.ENCRYPTER), {
    iv: CryptoJS.enc.Hex.parse(paymentConfigs.ENCRYPTER_IV),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return decrypted.toString(CryptoJS.enc.Utf8);  
}